function changeValue(pId, pValue) {
    document.getElementById(pId).value = pValue;
}
